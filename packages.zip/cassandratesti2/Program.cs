﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cassandra;

namespace cassandratesti2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello Cassandra!");

            var cluster = Cluster.Builder()
                                 .AddContactPoints("Samidb.ky.local")
                                 .WithPort(9042)
                                                             
                                 .Build();

            // Connect to the nodes using a keyspace
            var session = cluster.Connect("samiv4");

            // Get name of a Cluster
            Console.WriteLine("The cluster's name is: " + cluster.Metadata.ClusterName);
            
            session.Execute("INSERT INTO samiv4.measurementdata (providerid, sensortag, timebucket, timestamp) VALUES (1, 'test', '2019-10', '2019-10-28 10:29:32 +0300' ) IF NOT EXISTS;");



            
            // Execute a query on a connection synchronously
            var rs = session.Execute("SELECT * FROM samiv4.measurementdata");
            /*
            // Iterate through the RowSet
            foreach (var row in rs)
            {
                var value = row.GetValue<string>("sensortag");
                Console.WriteLine(value);
                // Do something with the value
            }
            */
            Console.WriteLine("nonii");
            Console.ReadKey();
        }
    }
}
